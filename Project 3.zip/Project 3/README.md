# Ford Gobike System Data
## by Akachukwu Ordu


## Dataset

This dataset includes information about individual rides made in a bike-sharing system covering the greater San Francisco Bay area. The Ford Gobike System Dataset contains 183412 row and 16 columns which had to undergo  data wrangling processes having Null values eleminated from the data set which left the dataset with 174952 rows and 16 coulumns. The Data set can be downloaded from https://video.udacity-data.com/topher/2020/October/5f91cf38_201902-fordgobike-tripdata/201902-fordgobike-tripdata.csv.  

## Summary of Findings

In the exploration, I found that there was a corrolation between day of the week and the usage of the Bike, showing that users use the bikes more during the week than weekend and it falls during opening and closing hours of work.
The dataset helps me deduce that the dominant users are of the male gender and dominant age range is 25 - 45 years  which falls in the working class demographic.


## Key Insights for Presentation

- Firstly, I go through the frequency for duration per minute of the riders which shows that majority of the users used the bike for short distances. Distances that took less than 20 minutes.using facetting for plotting the distribution of duration of each gender

- Secondly, i get to see that majority of our users are between the ages 20 and 90 years of age. which a scatter plot explains clearly.

- This shows the frequency of hours in the days of the week, showing the hours the bikes are used the most which is 8am and 5pm.
